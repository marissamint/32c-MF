# Installing and Using speedyflowplot v1.1

This guide explains how to install and use the speedyflowplot package version 1.1, which includes optimized functions for improved performance.

## Installation

### From Source

To install the package from source:

```r
# Install dependencies first
install.packages(c("grDevices", "graphics", "stats", "scales", "viridis"))

# If you don't have BiocManager installed
if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")

# Install Bioconductor dependencies
BiocManager::install(c("flowCore",  "flowWorkspace"))

# Install devtools if you don't have it
if (!requireNamespace("devtools", quietly = TRUE))
    install.packages("devtools")

# Install the package from the local directory
devtools::install("/path/to/speedyflowplot")
```

Replace `/path/to/speedyflowplot` with the actual path to the package directory.

## Using the Optimized Functions

### Basic Usage

The optimized functions have the same parameters as the original functions, making them easy to use as drop-in replacements:

```r
library(speedyflowplot)
library(flowCore)

# Load your flow cytometry data
ff <- read.FCS("your_data.fcs")

# Use the optimized version of PlotFlowFrame
PlotFlowFrame_optimized(
  obj = ff,
  channels = c("FSC-A", "SSC-A"),
  title = "My Plot"
)
```

### Performance Comparison

To compare the performance of the original and optimized functions:

```r
library(microbenchmark)

# Compare performance
benchmark <- microbenchmark(
  original = {
    PlotFlowFrame(
      obj = ff,
      channels = c("FSC-A", "SSC-A")
    )
  },
  optimized = {
    PlotFlowFrame_optimized(
      obj = ff,
      channels = c("FSC-A", "SSC-A")
    )
  },
  times = 5
)

print(benchmark)
```

### Using the GPU Functions (Placeholder)

The package includes placeholder GPU functions that currently fall back to the optimized CPU implementation:

```r
# Check if GPU is available (always returns FALSE in this version)
gpu_available <- gpu_is_available()

# Use the GPU version of PlotFlowFrame
PlotFlowFrame_gpu(
  obj = ff,
  channels = c("FSC-A", "SSC-A"),
  title = "GPU Plot"
)
```

## Example Scripts

The package includes example scripts that demonstrate the new functions:

- `examples/optimized_example.R`: Demonstrates the optimized functions
- `examples/gpu_example.R`: Demonstrates the placeholder GPU functions

To run these examples:

```r
# Source the example scripts
source(system.file("examples", "optimized_example.R", package = "speedyflowplot"))
source(system.file("examples", "gpu_example.R", package = "speedyflowplot"))
```

## Documentation

For more information about the optimization approach and potential GPU acceleration:

- `README_optimization.md`: Explains the optimization approach
- `docs/gpu_acceleration.md`: Details on how GPU acceleration would be implemented

## Troubleshooting

If you encounter any issues:

1. Make sure all dependencies are installed
2. Check that you're using the latest version of the package
3. Try reinstalling the package
4. If the issue persists, report it to the package maintainer
